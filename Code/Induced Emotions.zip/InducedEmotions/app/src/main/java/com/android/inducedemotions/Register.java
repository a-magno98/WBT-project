package com.android.inducedemotions;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Register extends AppCompatActivity {
    private EditText name, surname, age, email, password;
    private Button bntRegister;
    private Firebase ref;
    private User user;
    private final String URL = "https://wbt-project-2a2ba-default-rtdb.europe-west1.firebasedatabase.app/";
    private View login;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Firebase.setAndroidContext(this);
        name = findViewById(R.id.editTextName);
        surname = findViewById(R.id.editTextSurname);
        age = findViewById(R.id.editTextAge);
        email = findViewById(R.id.editTextRegEmail);
        password = findViewById(R.id.editTextRegPassword);
        bntRegister = findViewById(R.id.buttonRegister);
        login = findViewById(R.id.textViewRegLogin);
        user = new User();
        ref = new Firebase(URL).child("User");
        mAuth = FirebaseAuth.getInstance();

        bntRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ag = Integer.parseInt(age.getText().toString().trim());

                user.setName(name.getText().toString().trim());
                user.setSurname(surname.getText().toString().trim());
                user.setAge(ag);
                user.setEmaill(email.getText().toString().trim());
                user.setPassword(password.getText().toString().trim());

                createAccount(email.getText().toString().trim(), password.getText().toString().trim(), ref, user);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin();
            }
        });
    }

    private void openMenu(){
        Intent intent = new Intent(this, Menu.class);
        startActivity(intent);
    }

    private void openLogin(){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    private void createAccount(String email, String password, Firebase ref, User user_data) {
        // [START create_user_with_email]

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            //Log.d("SUCCESS CREATE USER", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            //upload data on database
                            ref.push().setValue(user_data);
                            openMenu();

                        } else {
                            // If sign in fails, display a message to the user.
                            //Log.w("FAILURE", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(Register.this, "Registration failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        // [END create_user_with_email]
    }
}